package au.com.auspost.mobility.postsub;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostcodeService {

	@Autowired
	private PostcodeSuburbRepository postcodeSuburbRepo;

	public List<PostcodeSuburb> getPostcode(String suburb) {
		List<PostcodeSuburb> postcodeSuburbList = new ArrayList<>();
		postcodeSuburbRepo.findAll().forEach(postcodeSuburbList::add);//
		return postcodeSuburbList.stream().filter(t -> t.getSuburb().equals(suburb)).collect(Collectors.toList());
	}
}
