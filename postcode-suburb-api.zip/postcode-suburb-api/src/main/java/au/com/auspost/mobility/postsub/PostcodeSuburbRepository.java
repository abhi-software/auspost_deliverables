package au.com.auspost.mobility.postsub;

import org.springframework.data.repository.CrudRepository;
import org.springframework.security.access.prepost.PreAuthorize;

public interface PostcodeSuburbRepository extends CrudRepository<PostcodeSuburb, RelationshipId>{
	  @SuppressWarnings("unchecked")
	  @PreAuthorize("hasRole('ROLE_ADMIN')")
	  @Override
	  PostcodeSuburb save(PostcodeSuburb s);
}
