package au.com.auspost.mobility.postsub;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
	@Autowired
	private PostcodeSuburbRepository postcodeSuburbRepo;

	public void addPostcodeSuburb(PostcodeSuburb postSub) {
		postcodeSuburbRepo.save(postSub);
	}

}
