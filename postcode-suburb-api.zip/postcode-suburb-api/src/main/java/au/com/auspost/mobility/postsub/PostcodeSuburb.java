package au.com.auspost.mobility.postsub;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@Entity
@IdClass(RelationshipId.class)
public class PostcodeSuburb {
    @Id
	private String postcode;
    @Id
	private String suburb;

    public PostcodeSuburb() {
		super();
	}
    
	public PostcodeSuburb(String postcode, String suburb) {
		super();

		this.postcode = postcode;
		this.suburb = suburb;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}

	@Override
	public String toString() {
		return "PostcodeSuburb [postcode=" + postcode + ", suburb=" + suburb + "]";
	}

	
}
