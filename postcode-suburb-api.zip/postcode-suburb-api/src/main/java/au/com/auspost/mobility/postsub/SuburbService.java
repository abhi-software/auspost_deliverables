package au.com.auspost.mobility.postsub;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SuburbService {
	@Autowired
	private PostcodeSuburbRepository postcodeSuburbRepo;
		
	public List<PostcodeSuburb> getSuburb(String postcode) {
		List<PostcodeSuburb> postcodeSuburbList = new ArrayList<>();
		postcodeSuburbRepo.findAll().forEach(postcodeSuburbList::add);
		return postcodeSuburbList.stream().filter(t -> t.getPostcode().equals(postcode)).collect(Collectors.toList());
		
	}

}
