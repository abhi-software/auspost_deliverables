package au.com.auspost.mobility.postsub;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PostcodeSuburbController {
	@Autowired
	private PostcodeService postcodeService;
	@Autowired
	private SuburbService suburbService;
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/postcode/{suburb}")
	public List<PostcodeSuburb> getPostcode(@PathVariable String suburb) {
		return postcodeService.getPostcode(suburb);
	}
	
	@RequestMapping("/suburb/{postcode}")
	public List<PostcodeSuburb> getSuburb(@PathVariable String postcode) {
		return suburbService.getSuburb(postcode);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/admin/postsub")
	public void addPostcodeSuburb(@RequestBody PostcodeSuburb postSub) {
		adminService.addPostcodeSuburb(postSub);
		
	}
}
