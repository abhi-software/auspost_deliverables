package au.com.auspost.mobility.postsub;

import java.io.Serializable;

public class RelationshipId implements Serializable{
	
	private static final long serialVersionUID = 4660817572964179871L;

	private String postcode;
    
	private String suburb;

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getSuburb() {
		return suburb;
	}

	public void setSuburb(String suburb) {
		this.suburb = suburb;
	}
	
	
}
